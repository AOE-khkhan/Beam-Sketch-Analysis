function ptype=identifysub(subparts)

% we have a choice of using different classifiers for identifying different
% components of the sketch