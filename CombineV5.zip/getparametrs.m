function [load,len]=getparametrs(beam,force)
%  
% if strcmp(class(beam),'cell')
% display('fuck')
% end
for i=1:length(force)
F=cell2mat(force(i).pnts);
end
load=100*(max(F(:))-min(F(:)));
len=10*(max(beam.pnts(:))-min(beam.pnts(:)));
display('its done');